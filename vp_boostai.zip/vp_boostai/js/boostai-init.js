(function ($, drupalSettings) {
  window._env_ = drupalSettings.vp_boostai.vp_boostai_settings;
})(jQuery, drupalSettings);
